import EmptyState from "./EmptyState";

const DataTable = ({ columns, rows, renderActions }) => {
  if (!rows.length) {
    return <EmptyState title="No data found" description="There is nothing to display for the current view." />;
  }

  return (
    <div className="overflow-hidden rounded-3xl border border-white/70 bg-white/95 shadow-soft">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-100">
          <thead className="bg-slate-50/80">
            <tr>
              {columns.map((column) => (
                <th key={column.key} className="px-4 py-4 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">{column.label}</th>
              ))}
              {renderActions ? <th className="px-4 py-4 text-right text-xs font-semibold uppercase tracking-wide text-slate-500">Actions</th> : null}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((row, index) => (
              <tr key={row.id || index}>
                {columns.map((column) => (
                  <td key={column.key} className="px-4 py-4 text-sm text-slate-700">{column.render ? column.render(row) : row[column.key]}</td>
                ))}
                {renderActions ? <td className="px-4 py-4 text-right">{renderActions(row)}</td> : null}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataTable;
