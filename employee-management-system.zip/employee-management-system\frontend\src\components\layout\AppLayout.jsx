import { Outlet, useLocation } from "react-router-dom";
import { useState } from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";

const titles = {
  "/admin/dashboard": "Admin Dashboard",
  "/employee/dashboard": "Employee Dashboard",
  "/admin/employees": "Employees",
  "/admin/departments": "Departments",
  "/admin/attendance": "Attendance",
  "/admin/leaves": "Leave Management",
  "/admin/payroll": "Payroll",
  "/employee/attendance": "My Attendance",
  "/employee/leaves": "My Leave History",
  "/employee/payroll": "My Payroll",
  "/profile": "Profile",
  "/change-password": "Change Password"
};

const AppLayout = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  return (
    <div className="min-h-screen">
      <Sidebar mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <main className="min-h-screen px-4 py-4 lg:ml-72 lg:px-8 lg:py-6">
        <Topbar title={titles[location.pathname] || "Employee Management System"} setMobileOpen={setMobileOpen} />
        <Outlet />
      </main>
    </div>
  );
};

export default AppLayout;
