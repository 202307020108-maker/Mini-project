import { formatCurrency } from "../../utils/format";

const StatCard = ({ title, value, icon: Icon, currency }) => (
  <div className="glass-card overflow-hidden p-5">
    <div className="mb-5 inline-flex rounded-2xl bg-gradient-to-br from-primary-500 to-sky-400 p-3 text-white">
      <Icon size={22} />
    </div>
    <p className="text-sm font-medium text-slate-500">{title}</p>
    <h3 className="mt-2 text-3xl font-bold text-slate-900">{currency ? formatCurrency(value) : value}</h3>
  </div>
);

export default StatCard;
