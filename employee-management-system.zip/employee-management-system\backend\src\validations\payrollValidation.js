import { body } from "express-validator";

export const payrollValidation = [
  body("employee_id").isInt({ min: 1 }).withMessage("Employee is required."),
  body("month").isInt({ min: 1, max: 12 }).withMessage("Month must be between 1 and 12."),
  body("year").isInt({ min: 2000 }).withMessage("Year is invalid."),
  body("basic_salary").isFloat({ min: 0 }).withMessage("Basic salary is invalid."),
  body("bonus").optional().isFloat({ min: 0 }).withMessage("Bonus is invalid."),
  body("deductions").optional().isFloat({ min: 0 }).withMessage("Deductions are invalid."),
  body("net_salary").isFloat({ min: 0 }).withMessage("Net salary is invalid."),
  body("payment_status").isIn(["paid", "pending", "processing"]).withMessage("Payment status is invalid.")
];
