const InputField = ({ label, className = "", ...props }) => (
  <label className="block">
    <span className="mb-2 block text-sm font-medium text-slate-600">{label}</span>
    <input
      {...props}
      className={`w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-primary-400 focus:ring-4 focus:ring-primary-100 ${className}`}
    />
  </label>
);

export default InputField;
