import { query } from "../config/db.js";
import { ROLES } from "../constants/index.js";
import AppError from "../utils/AppError.js";
import catchAsync from "../utils/catchAsync.js";
import { verifyToken } from "../utils/jwt.js";

export const protect = catchAsync(async (req, _res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return next(new AppError("Authentication required.", 401));
  }

  const token = authHeader.split(" ")[1];
  const decoded = verifyToken(token);

  if (decoded.role === ROLES.ADMIN) {
    const admins = await query(
      "SELECT id, name, email, role FROM admins WHERE id = :id LIMIT 1",
      { id: decoded.id }
    );
    if (!admins.length) return next(new AppError("Admin account not found.", 401));
    req.user = admins[0];
    return next();
  }

  const employees = await query(
    `SELECT e.id, e.employee_code, e.full_name, e.email, e.role, e.department_id,
            d.name AS department_name, e.profile_image
     FROM employees e
     LEFT JOIN departments d ON d.id = e.department_id
     WHERE e.id = :id LIMIT 1`,
    { id: decoded.id }
  );

  if (!employees.length) {
    return next(new AppError("Employee account not found.", 401));
  }

  req.user = employees[0];
  next();
});

export const authorize = (...roles) => (req, _res, next) => {
  if (!roles.includes(req.user.role)) {
    return next(new AppError("You are not allowed to access this resource.", 403));
  }
  next();
};
