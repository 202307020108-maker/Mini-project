DROP DATABASE IF EXISTS employee_management_system;
CREATE DATABASE employee_management_system;
USE employee_management_system;

CREATE TABLE departments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL UNIQUE,
  description TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE admins (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin') NOT NULL DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE employees (
  id INT PRIMARY KEY AUTO_INCREMENT,
  employee_code VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  gender ENUM('male', 'female', 'other') NOT NULL,
  dob DATE NOT NULL,
  address TEXT NOT NULL,
  department_id INT NOT NULL,
  designation VARCHAR(100) NOT NULL,
  salary DECIMAL(12, 2) NOT NULL DEFAULT 0,
  joining_date DATE NOT NULL,
  status ENUM('active', 'inactive', 'on_leave') NOT NULL DEFAULT 'active',
  role ENUM('admin', 'employee') NOT NULL DEFAULT 'employee',
  password VARCHAR(255) NOT NULL,
  profile_image VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_employees_department FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE TABLE attendance (
  id INT PRIMARY KEY AUTO_INCREMENT,
  employee_id INT NOT NULL,
  date DATE NOT NULL,
  status ENUM('present', 'absent', 'late', 'half_day', 'remote') NOT NULL DEFAULT 'present',
  check_in TIME NULL,
  check_out TIME NULL,
  remarks VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_attendance_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
  UNIQUE KEY uq_attendance_employee_date (employee_id, date)
);

CREATE TABLE leaves (
  id INT PRIMARY KEY AUTO_INCREMENT,
  employee_id INT NOT NULL,
  leave_type VARCHAR(60) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  reason TEXT NOT NULL,
  status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  admin_remark VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_leaves_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE TABLE payroll (
  id INT PRIMARY KEY AUTO_INCREMENT,
  employee_id INT NOT NULL,
  month INT NOT NULL,
  year INT NOT NULL,
  basic_salary DECIMAL(12, 2) NOT NULL,
  bonus DECIMAL(12, 2) NOT NULL DEFAULT 0,
  deductions DECIMAL(12, 2) NOT NULL DEFAULT 0,
  net_salary DECIMAL(12, 2) NOT NULL,
  payment_status ENUM('paid', 'pending', 'processing') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_payroll_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

INSERT INTO departments (name, description) VALUES
('Engineering', 'Product engineering, QA, and software delivery team.'),
('Human Resources', 'Employee relations, hiring, onboarding, and policies.'),
('Finance', 'Payroll, vendor payments, and business reporting.'),
('Marketing', 'Campaign planning, branding, and content.'),
('Operations', 'Day-to-day process execution and coordination.');

INSERT INTO admins (name, email, password, role) VALUES
('System Administrator', 'admin@ems.com', '$2a$10$i.RiIPW5wSSooTHJI6Sl6usKdx94uAmSUZ8489.os9OKLWGcuO6tm', 'admin');

INSERT INTO employees (
  employee_code, full_name, email, phone, gender, dob, address, department_id,
  designation, salary, joining_date, status, role, password, profile_image
) VALUES
('EMP001', 'Neha Sharma', 'neha.sharma@ems.com', '9876543210', 'female', '1998-05-14', 'Bhopal, Madhya Pradesh', 1, 'Frontend Developer', 68000, '2023-07-10', 'active', 'employee', '$2a$10$i.RiIPW5wSSooTHJI6Sl6usKdx94uAmSUZ8489.os9OKLWGcuO6tm', NULL),
('EMP002', 'Arjun Mehta', 'arjun.mehta@ems.com', '9876543211', 'male', '1996-11-02', 'Pune, Maharashtra', 1, 'Backend Developer', 72000, '2022-02-15', 'active', 'employee', '$2a$10$i.RiIPW5wSSooTHJI6Sl6usKdx94uAmSUZ8489.os9OKLWGcuO6tm', NULL),
('EMP003', 'Riya Patel', 'riya.patel@ems.com', '9876543212', 'female', '1997-03-19', 'Ahmedabad, Gujarat', 2, 'HR Executive', 55000, '2021-09-21', 'active', 'employee', '$2a$10$i.RiIPW5wSSooTHJI6Sl6usKdx94uAmSUZ8489.os9OKLWGcuO6tm', NULL),
('EMP004', 'Karan Singh', 'karan.singh@ems.com', '9876543213', 'male', '1995-08-28', 'Jaipur, Rajasthan', 3, 'Finance Analyst', 60000, '2020-12-01', 'on_leave', 'employee', '$2a$10$i.RiIPW5wSSooTHJI6Sl6usKdx94uAmSUZ8489.os9OKLWGcuO6tm', NULL),
('EMP005', 'Aisha Khan', 'aisha.khan@ems.com', '9876543214', 'female', '1999-01-11', 'Lucknow, Uttar Pradesh', 4, 'Marketing Specialist', 50000, '2024-01-05', 'active', 'employee', '$2a$10$i.RiIPW5wSSooTHJI6Sl6usKdx94uAmSUZ8489.os9OKLWGcuO6tm', NULL);

INSERT INTO attendance (employee_id, date, status, check_in, check_out, remarks) VALUES
(1, '2026-04-08', 'present', '09:10:00', '18:08:00', 'Worked on dashboard UI'),
(1, '2026-04-09', 'remote', '09:02:00', '18:20:00', 'WFH sprint review'),
(1, '2026-04-10', 'late', '09:35:00', '18:15:00', 'Traffic delay'),
(2, '2026-04-08', 'present', '09:00:00', '18:12:00', 'API integration'),
(2, '2026-04-09', 'present', '08:58:00', '18:05:00', 'Payroll bug fixes'),
(3, '2026-04-08', 'present', '09:15:00', '17:55:00', 'Candidate screening'),
(3, '2026-04-09', 'half_day', '09:22:00', '13:05:00', 'Medical appointment'),
(4, '2026-04-08', 'absent', NULL, NULL, 'Approved leave'),
(5, '2026-04-08', 'present', '09:05:00', '18:00:00', 'Campaign planning');

INSERT INTO leaves (employee_id, leave_type, start_date, end_date, reason, status, admin_remark) VALUES
(1, 'Casual Leave', '2026-04-18', '2026-04-19', 'Family function', 'pending', NULL),
(3, 'Sick Leave', '2026-04-11', '2026-04-11', 'Fever and rest', 'approved', 'Approved by admin'),
(4, 'Annual Leave', '2026-04-08', '2026-04-12', 'Personal travel', 'approved', 'Approved in advance');

INSERT INTO payroll (employee_id, month, year, basic_salary, bonus, deductions, net_salary, payment_status) VALUES
(1, 3, 2026, 68000, 5000, 2000, 71000, 'paid'),
(2, 3, 2026, 72000, 3000, 1000, 74000, 'paid'),
(3, 3, 2026, 55000, 2500, 500, 57000, 'paid'),
(4, 3, 2026, 60000, 0, 3000, 57000, 'processing'),
(5, 3, 2026, 50000, 2000, 700, 51300, 'pending');
