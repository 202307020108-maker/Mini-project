import { body } from "express-validator";

export const attendanceValidation = [
  body("employee_id").isInt({ min: 1 }).withMessage("Employee is required."),
  body("date").isISO8601().withMessage("Date is required."),
  body("status").isIn(["present", "absent", "late", "half_day", "remote"]).withMessage("Attendance status is invalid."),
  body("check_in").optional({ values: "falsy" }).trim(),
  body("check_out").optional({ values: "falsy" }).trim(),
  body("remarks").optional().trim()
];
