import { query } from "../config/db.js";
import { ROLES } from "../constants/index.js";
import AppError from "../utils/AppError.js";
import { successResponse } from "../utils/apiResponse.js";
import catchAsync from "../utils/catchAsync.js";

export const getLeaves = catchAsync(async (req, res) => {
  const employeeId = req.user.role === ROLES.ADMIN ? req.query.employeeId : req.user.id;
  const status = req.query.status || "";
  let where = " WHERE 1=1 ";
  const params = {};

  if (employeeId) {
    where += " AND l.employee_id = :employeeId";
    params.employeeId = Number(employeeId);
  }
  if (status) {
    where += " AND l.status = :status";
    params.status = status;
  }

  const rows = await query(
    `SELECT l.*, e.full_name, e.employee_code
     FROM leaves l
     INNER JOIN employees e ON e.id = l.employee_id
     ${where}
     ORDER BY l.created_at DESC`,
    params
  );
  successResponse(res, "Leave requests fetched successfully.", rows);
});

export const createLeave = catchAsync(async (req, res) => {
  const employeeId = req.user.role === ROLES.ADMIN ? req.body.employee_id : req.user.id;
  const { leave_type, start_date, end_date, reason } = req.body;
  const result = await query(
    `INSERT INTO leaves (employee_id, leave_type, start_date, end_date, reason, status)
     VALUES (:employee_id, :leave_type, :start_date, :end_date, :reason, 'pending')`,
    { employee_id: employeeId, leave_type, start_date, end_date, reason }
  );
  const rows = await query("SELECT * FROM leaves WHERE id = :id LIMIT 1", { id: result.insertId });
  successResponse(res, "Leave request submitted successfully.", rows[0], 201);
});

export const updateLeaveStatus = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const existing = await query("SELECT id FROM leaves WHERE id = :id LIMIT 1", { id });
  if (!existing.length) return next(new AppError("Leave request not found.", 404));
  await query(
    "UPDATE leaves SET status = :status, admin_remark = :admin_remark WHERE id = :id",
    { id, status: req.body.status, admin_remark: req.body.admin_remark || null }
  );
  const rows = await query("SELECT * FROM leaves WHERE id = :id LIMIT 1", { id });
  successResponse(res, "Leave status updated successfully.", rows[0]);
});
