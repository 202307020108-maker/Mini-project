import express from "express";
import { createAttendance, deleteAttendance, getAttendance, updateAttendance } from "../controllers/attendanceController.js";
import { authorize, protect } from "../middleware/auth.js";
import validate from "../middleware/validate.js";
import { attendanceValidation } from "../validations/attendanceValidation.js";

const router = express.Router();

router.use(protect);
router.get("/", getAttendance);
router.post("/", authorize("admin"), attendanceValidation, validate, createAttendance);
router.put("/:id", authorize("admin"), attendanceValidation, validate, updateAttendance);
router.delete("/:id", authorize("admin"), deleteAttendance);

export default router;
