import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import api from "../api/axios";
import ConfirmModal from "../components/common/ConfirmModal";
import DataTable from "../components/common/DataTable";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import InputField from "../components/forms/InputField";

const DepartmentsPage = () => {
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: "", description: "" });
  const fetchDepartments = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/departments");
      setDepartments(data.data);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { fetchDepartments(); }, []);
  const submitDepartment = async (event) => {
    event.preventDefault();
    if (editing) { await api.put(`/departments/${editing.id}`, form); toast.success("Department updated."); } else { await api.post("/departments", form); toast.success("Department created."); }
    setForm({ name: "", description: "" }); setEditing(null); fetchDepartments();
  };
  const deleteDepartment = async () => { await api.delete(`/departments/${deleteTarget.id}`); toast.success("Department deleted."); setDeleteTarget(null); fetchDepartments(); };
  if (loading) return <Loader label="Loading departments..." />;
  return (
    <div>
      <PageHeader title="Departments" subtitle="Create and maintain the organizational structure for employees." />
      <div className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
        <form className="glass-card space-y-5 p-6" onSubmit={submitDepartment}>
          <InputField label="Department Name" name="name" value={form.name} onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))} required />
          <label className="block"><span className="mb-2 block text-sm font-medium text-slate-600">Description</span><textarea name="description" value={form.description} onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))} rows="4" className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-primary-400 focus:ring-4 focus:ring-primary-100" /></label>
          <div className="flex gap-3"><button type="submit" className="rounded-2xl bg-primary-600 px-4 py-3 text-sm font-semibold text-white">{editing ? "Update Department" : "Create Department"}</button>{editing ? <button type="button" onClick={() => { setEditing(null); setForm({ name: "", description: "" }); }} className="rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-700">Cancel</button> : null}</div>
        </form>
        <DataTable columns={[{ key: "name", label: "Department" }, { key: "description", label: "Description" }, { key: "employee_count", label: "Employees" }]} rows={departments} renderActions={(row) => <div className="flex justify-end gap-2"><button type="button" onClick={() => { setEditing(row); setForm({ name: row.name, description: row.description || "" }); }} className="rounded-xl border border-slate-200 px-3 py-2 text-primary-700">Edit</button><button type="button" onClick={() => setDeleteTarget(row)} className="rounded-xl border border-rose-200 px-3 py-2 text-rose-600">Delete</button></div>} />
      </div>
      <ConfirmModal open={Boolean(deleteTarget)} title="Delete department" description={`Delete ${deleteTarget?.name || "this department"}?`} onCancel={() => setDeleteTarget(null)} onConfirm={deleteDepartment} />
    </div>
  );
};

export default DepartmentsPage;
