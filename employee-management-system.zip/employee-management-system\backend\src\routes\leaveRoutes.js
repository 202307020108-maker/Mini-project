import express from "express";
import { createLeave, getLeaves, updateLeaveStatus } from "../controllers/leaveController.js";
import { authorize, protect } from "../middleware/auth.js";
import validate from "../middleware/validate.js";
import { leaveCreateValidation, leaveStatusValidation } from "../validations/leaveValidation.js";

const router = express.Router();

router.use(protect);
router.get("/", getLeaves);
router.post("/", leaveCreateValidation, validate, createLeave);
router.patch("/:id/status", authorize("admin"), leaveStatusValidation, validate, updateLeaveStatus);

export default router;
