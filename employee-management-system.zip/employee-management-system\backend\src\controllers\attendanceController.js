import { query } from "../config/db.js";
import { ROLES } from "../constants/index.js";
import AppError from "../utils/AppError.js";
import { successResponse } from "../utils/apiResponse.js";
import catchAsync from "../utils/catchAsync.js";

export const getAttendance = catchAsync(async (req, res) => {
  const employeeId = req.user.role === ROLES.ADMIN ? req.query.employeeId : req.user.id;
  const month = req.query.month || "";
  const year = req.query.year || "";
  let where = " WHERE 1=1 ";
  const params = {};

  if (employeeId) {
    where += " AND a.employee_id = :employeeId";
    params.employeeId = Number(employeeId);
  }
  if (month) {
    where += " AND MONTH(a.date) = :month";
    params.month = Number(month);
  }
  if (year) {
    where += " AND YEAR(a.date) = :year";
    params.year = Number(year);
  }

  const rows = await query(
    `SELECT a.*, e.full_name, e.employee_code
     FROM attendance a
     INNER JOIN employees e ON e.id = a.employee_id
     ${where}
     ORDER BY a.date DESC`,
    params
  );
  successResponse(res, "Attendance fetched successfully.", rows);
});

export const createAttendance = catchAsync(async (req, res) => {
  const { employee_id, date, status, check_in, check_out, remarks } = req.body;
  const result = await query(
    `INSERT INTO attendance (employee_id, date, status, check_in, check_out, remarks)
     VALUES (:employee_id, :date, :status, :check_in, :check_out, :remarks)`,
    { employee_id, date, status, check_in: check_in || null, check_out: check_out || null, remarks: remarks || null }
  );
  const rows = await query("SELECT * FROM attendance WHERE id = :id LIMIT 1", { id: result.insertId });
  successResponse(res, "Attendance created successfully.", rows[0], 201);
});

export const updateAttendance = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const existing = await query("SELECT id FROM attendance WHERE id = :id LIMIT 1", { id });
  if (!existing.length) return next(new AppError("Attendance record not found.", 404));
  const { employee_id, date, status, check_in, check_out, remarks } = req.body;
  await query(
    `UPDATE attendance
     SET employee_id = :employee_id, date = :date, status = :status,
         check_in = :check_in, check_out = :check_out, remarks = :remarks
     WHERE id = :id`,
    { id, employee_id, date, status, check_in: check_in || null, check_out: check_out || null, remarks: remarks || null }
  );
  const rows = await query("SELECT * FROM attendance WHERE id = :id LIMIT 1", { id });
  successResponse(res, "Attendance updated successfully.", rows[0]);
});

export const deleteAttendance = catchAsync(async (req, res) => {
  await query("DELETE FROM attendance WHERE id = :id", { id: req.params.id });
  successResponse(res, "Attendance deleted successfully.");
});
