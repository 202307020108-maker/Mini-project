import { body } from "express-validator";

export const departmentValidation = [
  body("name").trim().notEmpty().withMessage("Department name is required."),
  body("description").optional().trim()
];
