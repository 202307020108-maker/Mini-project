export const formatCurrency = (value) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(Number(value || 0));

export const formatDate = (value) =>
  value ? new Date(value).toLocaleDateString("en-IN", { dateStyle: "medium" }) : "-";

export const getStatusClasses = (value = "") => {
  const map = {
    active: "bg-emerald-100 text-emerald-700",
    inactive: "bg-slate-200 text-slate-700",
    on_leave: "bg-amber-100 text-amber-700",
    present: "bg-emerald-100 text-emerald-700",
    paid: "bg-emerald-100 text-emerald-700",
    approved: "bg-emerald-100 text-emerald-700",
    pending: "bg-amber-100 text-amber-700",
    processing: "bg-sky-100 text-sky-700",
    rejected: "bg-rose-100 text-rose-700",
    absent: "bg-rose-100 text-rose-700",
    late: "bg-orange-100 text-orange-700",
    half_day: "bg-violet-100 text-violet-700",
    remote: "bg-blue-100 text-blue-700"
  };
  return map[value] || "bg-slate-100 text-slate-700";
};
