import express from "express";
import { changePassword, getCurrentUser, login } from "../controllers/authController.js";
import { protect } from "../middleware/auth.js";
import validate from "../middleware/validate.js";
import { changePasswordValidation, loginValidation } from "../validations/authValidation.js";

const router = express.Router();

router.post("/login", loginValidation, validate, login);
router.get("/me", protect, getCurrentUser);
router.patch("/change-password", protect, changePasswordValidation, validate, changePassword);

export default router;
