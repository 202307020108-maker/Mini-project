const EmptyState = ({ title, description }) => (
  <div className="glass-card flex min-h-[220px] flex-col items-center justify-center px-6 py-10 text-center">
    <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
    <p className="mt-2 max-w-md text-sm text-slate-500">{description}</p>
  </div>
);

export default EmptyState;
