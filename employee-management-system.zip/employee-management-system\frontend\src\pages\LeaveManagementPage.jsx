import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import api from "../api/axios";
import DataTable from "../components/common/DataTable";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import StatusBadge from "../components/common/StatusBadge";
import InputField from "../components/forms/InputField";
import SelectField from "../components/forms/SelectField";
import { formatDate } from "../utils/format";

const LeaveManagementPage = ({ mode }) => {
  const isAdmin = mode === "admin";
  const [leaves, setLeaves] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ employee_id: "", leave_type: "Casual Leave", start_date: "", end_date: "", reason: "" });

  const fetchData = async () => {
    setLoading(true);
    try {
      const requests = [api.get("/leaves")];
      if (isAdmin) requests.push(api.get("/employees", { params: { limit: 100, page: 1 } }));
      const [leaveRes, employeeRes] = await Promise.all(requests);
      setLeaves(leaveRes.data.data);
      if (employeeRes) setEmployees(employeeRes.data.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [mode]);
  const submitLeave = async (event) => {
    event.preventDefault();
    await api.post("/leaves", form);
    toast.success("Leave request submitted.");
    setForm({ employee_id: "", leave_type: "Casual Leave", start_date: "", end_date: "", reason: "" });
    fetchData();
  };
  const updateStatus = async (id, status) => {
    await api.patch(`/leaves/${id}/status`, { status, admin_remark: `${status} by admin` });
    toast.success(`Leave ${status}.`);
    fetchData();
  };
  if (loading) return <Loader label="Loading leave records..." />;
  return (
    <div>
      <PageHeader title={isAdmin ? "Leave Management" : "Leave Requests"} subtitle={isAdmin ? "Review, approve, or reject employee leave requests." : "Apply for leave and track your request history."} />
      <form className="glass-card mb-6 grid gap-4 p-5 md:grid-cols-2 xl:grid-cols-5" onSubmit={submitLeave}>
        {isAdmin ? <SelectField label="Employee" name="employee_id" value={form.employee_id} onChange={(e) => setForm((prev) => ({ ...prev, employee_id: e.target.value }))} options={[{ label: "Select employee", value: "" }, ...employees.map((item) => ({ label: `${item.full_name} (${item.employee_code})`, value: item.id }))]} /> : null}
        <InputField label="Leave Type" name="leave_type" value={form.leave_type} onChange={(e) => setForm((prev) => ({ ...prev, leave_type: e.target.value }))} required />
        <InputField label="Start Date" name="start_date" type="date" value={form.start_date} onChange={(e) => setForm((prev) => ({ ...prev, start_date: e.target.value }))} required />
        <InputField label="End Date" name="end_date" type="date" value={form.end_date} onChange={(e) => setForm((prev) => ({ ...prev, end_date: e.target.value }))} required />
        <InputField label="Reason" name="reason" value={form.reason} onChange={(e) => setForm((prev) => ({ ...prev, reason: e.target.value }))} required />
        <div className="flex items-end"><button type="submit" className="w-full rounded-2xl bg-primary-600 px-4 py-3 text-sm font-semibold text-white">Apply Leave</button></div>
      </form>
      <DataTable columns={[...(isAdmin ? [{ key: "full_name", label: "Employee" }] : []), { key: "leave_type", label: "Type" }, { key: "start_date", label: "Start", render: (row) => formatDate(row.start_date) }, { key: "end_date", label: "End", render: (row) => formatDate(row.end_date) }, { key: "reason", label: "Reason" }, { key: "status", label: "Status", render: (row) => <StatusBadge value={row.status} /> }, { key: "admin_remark", label: "Admin Remark" }]} rows={leaves} renderActions={isAdmin ? (row) => row.status === "pending" ? <div className="flex justify-end gap-2"><button type="button" onClick={() => updateStatus(row.id, "approved")} className="rounded-xl border border-emerald-200 px-3 py-2 text-emerald-600">Approve</button><button type="button" onClick={() => updateStatus(row.id, "rejected")} className="rounded-xl border border-rose-200 px-3 py-2 text-rose-600">Reject</button></div> : null : null} />
    </div>
  );
};

export default LeaveManagementPage;
