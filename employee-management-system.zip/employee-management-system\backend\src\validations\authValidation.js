import { body } from "express-validator";

export const loginValidation = [
  body("email").isEmail().withMessage("Valid email is required."),
  body("password").isLength({ min: 4 }).withMessage("Password must be at least 4 characters long.")
];

export const changePasswordValidation = [
  body("currentPassword").notEmpty().withMessage("Current password is required."),
  body("newPassword").isLength({ min: 6 }).withMessage("New password must be at least 6 characters long.")
];
