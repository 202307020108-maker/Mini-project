import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import InputField from "../components/forms/InputField";
import { useAuth } from "../context/AuthContext";

const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const [form, setForm] = useState({ email: "admin@ems.com", password: "bacon" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const user = await login(form);
      navigate(location.state?.from?.pathname || (user.role === "admin" ? "/admin/dashboard" : "/employee/dashboard"), { replace: true });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.1fr_0.9fr]">
      <section className="hidden bg-[#0b2148] px-10 py-14 text-white lg:flex lg:flex-col lg:justify-center">
        <h1 className="text-5xl font-bold leading-tight">Modern Employee Management System</h1>
        <p className="mt-5 text-lg text-sky-100">Full-stack college-ready project with admin and employee workflows.</p>
      </section>
      <section className="flex items-center justify-center px-5 py-10">
        <div className="glass-card w-full max-w-md p-8">
          <h2 className="text-3xl font-bold text-slate-900">Sign in to EMS Pro</h2>
          <form className="mt-8 space-y-5" onSubmit={handleSubmit}>
            <InputField label="Email" name="email" type="email" value={form.email} onChange={(e) => setForm((prev) => ({ ...prev, email: e.target.value }))} required />
            <InputField label="Password" name="password" type="password" value={form.password} onChange={(e) => setForm((prev) => ({ ...prev, password: e.target.value }))} required />
            <button type="submit" disabled={loading} className="w-full rounded-2xl bg-gradient-to-r from-primary-600 to-sky-500 px-4 py-3 text-sm font-semibold text-white">
              {loading ? "Signing in..." : "Sign In"}
            </button>
          </form>
          <div className="mt-8 grid gap-3 rounded-2xl bg-slate-50 p-4 text-sm text-slate-600">
            <div><p className="font-semibold text-slate-900">Admin Demo</p><p>Email: admin@ems.com</p><p>Password: bacon</p></div>
            <div><p className="font-semibold text-slate-900">Employee Demo</p><p>Email: neha.sharma@ems.com</p><p>Password: bacon</p></div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LoginPage;
