import InputField from "./InputField";
import SelectField from "./SelectField";

const EmployeeForm = ({ form, departments, onChange, onSubmit, loading, submitLabel }) => (
  <form className="glass-card grid gap-5 p-6 md:grid-cols-2" onSubmit={onSubmit}>
    <InputField label="Employee Code" name="employee_code" value={form.employee_code} onChange={onChange} required />
    <InputField label="Full Name" name="full_name" value={form.full_name} onChange={onChange} required />
    <InputField label="Email" name="email" type="email" value={form.email} onChange={onChange} required />
    <InputField label="Phone" name="phone" value={form.phone} onChange={onChange} required />
    <SelectField label="Gender" name="gender" value={form.gender} onChange={onChange} options={[{ label: "Male", value: "male" }, { label: "Female", value: "female" }, { label: "Other", value: "other" }]} />
    <InputField label="Date of Birth" name="dob" type="date" value={form.dob} onChange={onChange} required />
    <label className="block md:col-span-2">
      <span className="mb-2 block text-sm font-medium text-slate-600">Address</span>
      <textarea name="address" value={form.address} onChange={onChange} rows="4" className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-primary-400 focus:ring-4 focus:ring-primary-100" />
    </label>
    <SelectField label="Department" name="department_id" value={form.department_id} onChange={onChange} options={[{ label: "Select department", value: "" }, ...departments.map((department) => ({ label: department.name, value: department.id }))]} />
    <InputField label="Designation" name="designation" value={form.designation} onChange={onChange} required />
    <InputField label="Salary" name="salary" type="number" value={form.salary} onChange={onChange} required />
    <InputField label="Joining Date" name="joining_date" type="date" value={form.joining_date} onChange={onChange} required />
    <SelectField label="Status" name="status" value={form.status} onChange={onChange} options={[{ label: "Active", value: "active" }, { label: "Inactive", value: "inactive" }, { label: "On Leave", value: "on_leave" }]} />
    <SelectField label="Role" name="role" value={form.role} onChange={onChange} options={[{ label: "Employee", value: "employee" }, { label: "Admin", value: "admin" }]} />
    <InputField label="Password" name="password" type="password" value={form.password} onChange={onChange} />
    <InputField label="Profile Photo" name="profile_image" type="file" accept="image/*" className="file:mr-4 file:rounded-xl file:border-0 file:bg-primary-50 file:px-3 file:py-2 file:text-primary-700" />
    <div className="md:col-span-2">
      <button type="submit" disabled={loading} className="rounded-2xl bg-primary-600 px-5 py-3 text-sm font-semibold text-white">{loading ? "Saving..." : submitLabel}</button>
    </div>
  </form>
);

export default EmployeeForm;
