import { body } from "express-validator";

export const leaveCreateValidation = [
  body("employee_id").optional().isInt({ min: 1 }).withMessage("Employee is invalid."),
  body("leave_type").trim().notEmpty().withMessage("Leave type is required."),
  body("start_date").isISO8601().withMessage("Start date is required."),
  body("end_date").isISO8601().withMessage("End date is required."),
  body("reason").trim().notEmpty().withMessage("Reason is required.")
];

export const leaveStatusValidation = [
  body("status").isIn(["pending", "approved", "rejected"]).withMessage("Status is invalid."),
  body("admin_remark").optional().trim()
];
