import { Link } from "react-router-dom";

const UnauthorizedPage = () => (
  <div className="flex min-h-screen items-center justify-center px-4">
    <div className="glass-card max-w-lg p-8 text-center">
      <p className="text-sm font-semibold uppercase tracking-[0.3em] text-rose-500">403</p>
      <h1 className="mt-3 text-3xl font-bold text-slate-900">Unauthorized Access</h1>
      <p className="mt-3 text-sm text-slate-500">Your role does not have permission to access this page.</p>
      <Link to="/login" className="mt-6 inline-flex rounded-2xl bg-primary-600 px-5 py-3 text-sm font-semibold text-white">Back to Login</Link>
    </div>
  </div>
);

export default UnauthorizedPage;
