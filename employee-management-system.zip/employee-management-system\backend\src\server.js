import app from "./app.js";
import env from "./config/env.js";

app.listen(env.port, () => {
  console.log(`EMS backend running on http://localhost:${env.port}`);
});
