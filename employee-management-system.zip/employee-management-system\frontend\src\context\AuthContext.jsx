import { createContext, useContext, useEffect, useState } from "react";
import { toast } from "react-toastify";
import api from "../api/axios";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("ems_token"));
  const [loading, setLoading] = useState(Boolean(localStorage.getItem("ems_token")));

  const storeAuth = (payload) => {
    localStorage.setItem("ems_token", payload.token);
    localStorage.setItem("ems_user", JSON.stringify(payload.user));
    setToken(payload.token);
    setUser(payload.user);
  };

  const clearAuth = () => {
    localStorage.removeItem("ems_token");
    localStorage.removeItem("ems_user");
    setToken(null);
    setUser(null);
  };

  const login = async (values) => {
    const { data } = await api.post("/auth/login", values);
    storeAuth(data.data);
    toast.success("Welcome back!");
    return data.data.user;
  };

  const logout = () => {
    clearAuth();
    toast.info("Logged out successfully.");
  };

  const refreshUser = async () => {
    if (!localStorage.getItem("ems_token")) {
      setLoading(false);
      return null;
    }
    try {
      const { data } = await api.get("/auth/me");
      setUser(data.data);
      localStorage.setItem("ems_user", JSON.stringify(data.data));
      return data.data;
    } catch {
      clearAuth();
      return null;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const cachedUser = localStorage.getItem("ems_user");
    if (cachedUser && !user) setUser(JSON.parse(cachedUser));
    refreshUser();
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, loading, isAuthenticated: Boolean(token), login, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
