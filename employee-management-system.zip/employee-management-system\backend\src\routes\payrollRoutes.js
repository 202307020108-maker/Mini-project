import express from "express";
import { createPayroll, deletePayroll, getPayrolls, updatePayroll } from "../controllers/payrollController.js";
import { authorize, protect } from "../middleware/auth.js";
import validate from "../middleware/validate.js";
import { payrollValidation } from "../validations/payrollValidation.js";

const router = express.Router();

router.use(protect);
router.get("/", getPayrolls);
router.post("/", authorize("admin"), payrollValidation, validate, createPayroll);
router.put("/:id", authorize("admin"), payrollValidation, validate, updatePayroll);
router.delete("/:id", authorize("admin"), deletePayroll);

export default router;
