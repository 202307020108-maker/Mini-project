import { query } from "../config/db.js";
import { ROLES } from "../constants/index.js";
import AppError from "../utils/AppError.js";
import { successResponse } from "../utils/apiResponse.js";
import catchAsync from "../utils/catchAsync.js";

export const getPayrolls = catchAsync(async (req, res) => {
  const employeeId = req.user.role === ROLES.ADMIN ? req.query.employeeId : req.user.id;
  const month = req.query.month || "";
  const year = req.query.year || "";
  let where = " WHERE 1=1 ";
  const params = {};

  if (employeeId) {
    where += " AND p.employee_id = :employeeId";
    params.employeeId = Number(employeeId);
  }
  if (month) {
    where += " AND p.month = :month";
    params.month = Number(month);
  }
  if (year) {
    where += " AND p.year = :year";
    params.year = Number(year);
  }

  const rows = await query(
    `SELECT p.*, e.full_name, e.employee_code
     FROM payroll p
     INNER JOIN employees e ON e.id = p.employee_id
     ${where}
     ORDER BY p.year DESC, p.month DESC`,
    params
  );
  successResponse(res, "Payroll records fetched successfully.", rows);
});

export const createPayroll = catchAsync(async (req, res) => {
  const body = req.body;
  const result = await query(
    `INSERT INTO payroll (
      employee_id, month, year, basic_salary, bonus, deductions, net_salary, payment_status
    ) VALUES (
      :employee_id, :month, :year, :basic_salary, :bonus, :deductions, :net_salary, :payment_status
    )`,
    { ...body, bonus: body.bonus || 0, deductions: body.deductions || 0 }
  );
  const rows = await query("SELECT * FROM payroll WHERE id = :id LIMIT 1", { id: result.insertId });
  successResponse(res, "Payroll created successfully.", rows[0], 201);
});

export const updatePayroll = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const existing = await query("SELECT id FROM payroll WHERE id = :id LIMIT 1", { id });
  if (!existing.length) return next(new AppError("Payroll record not found.", 404));
  const body = req.body;
  await query(
    `UPDATE payroll
     SET employee_id = :employee_id, month = :month, year = :year,
         basic_salary = :basic_salary, bonus = :bonus, deductions = :deductions,
         net_salary = :net_salary, payment_status = :payment_status
     WHERE id = :id`,
    { id, ...body, bonus: body.bonus || 0, deductions: body.deductions || 0 }
  );
  const rows = await query("SELECT * FROM payroll WHERE id = :id LIMIT 1", { id });
  successResponse(res, "Payroll updated successfully.", rows[0]);
});

export const deletePayroll = catchAsync(async (req, res) => {
  await query("DELETE FROM payroll WHERE id = :id", { id: req.params.id });
  successResponse(res, "Payroll deleted successfully.");
});
