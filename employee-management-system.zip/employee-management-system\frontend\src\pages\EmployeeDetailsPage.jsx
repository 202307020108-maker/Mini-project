import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api from "../api/axios";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import StatusBadge from "../components/common/StatusBadge";
import { formatCurrency, formatDate } from "../utils/format";

const EmployeeDetailsPage = () => {
  const { id } = useParams();
  const [employee, setEmployee] = useState(null);
  useEffect(() => { api.get(`/employees/${id}`).then(({ data }) => setEmployee(data.data)); }, [id]);
  if (!employee) return <Loader label="Loading employee profile..." />;
  return (
    <div>
      <PageHeader title="Employee Details" subtitle="Detailed profile view for admin review and management." action={<Link to={`/admin/employees/${id}/edit`} className="rounded-2xl bg-primary-600 px-4 py-3 text-sm font-semibold text-white">Edit Employee</Link>} />
      <div className="glass-card grid gap-4 p-6 md:grid-cols-2">
        <div><p className="text-sm text-slate-500">Name</p><p className="mt-1 font-semibold text-slate-900">{employee.full_name}</p></div>
        <div><p className="text-sm text-slate-500">Employee Code</p><p className="mt-1 font-semibold text-slate-900">{employee.employee_code}</p></div>
        <div><p className="text-sm text-slate-500">Department</p><p className="mt-1 font-semibold text-slate-900">{employee.department_name}</p></div>
        <div><p className="text-sm text-slate-500">Status</p><div className="mt-1"><StatusBadge value={employee.status} /></div></div>
        <div><p className="text-sm text-slate-500">Joining Date</p><p className="mt-1 font-semibold text-slate-900">{formatDate(employee.joining_date)}</p></div>
        <div><p className="text-sm text-slate-500">Salary</p><p className="mt-1 font-semibold text-slate-900">{formatCurrency(employee.salary)}</p></div>
        <div className="md:col-span-2"><p className="text-sm text-slate-500">Address</p><p className="mt-1 font-semibold text-slate-900">{employee.address}</p></div>
      </div>
    </div>
  );
};

export default EmployeeDetailsPage;
