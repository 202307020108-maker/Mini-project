import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../api/axios";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import InputField from "../components/forms/InputField";
import SelectField from "../components/forms/SelectField";
import { useAuth } from "../context/AuthContext";

const ProfilePage = () => {
  const { user, refreshUser } = useAuth();
  const [form, setForm] = useState({ full_name: "", phone: "", gender: "female", dob: "", address: "" });
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (user?.role === "employee") {
      setForm({ full_name: user.full_name || "", phone: user.phone || "", gender: user.gender || "female", dob: user.dob ? user.dob.slice(0, 10) : "", address: user.address || "" });
    }
  }, [user]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    const payload = new FormData();
    Object.entries(form).forEach(([key, value]) => payload.append(key, value));
    const file = event.target.profile_image.files[0];
    if (file) payload.append("profile_image", file);
    try {
      await api.patch("/employees/me/profile", payload);
      await refreshUser();
      toast.success("Profile updated successfully.");
    } finally {
      setLoading(false);
    }
  };

  if (!user) return <Loader label="Loading profile..." />;
  return (
    <div>
      <PageHeader title="Profile" subtitle={user.role === "admin" ? "Account details for the administrator." : "Update your personal details and keep your information current."} action={<Link to="/change-password" className="rounded-2xl bg-primary-600 px-4 py-3 text-sm font-semibold text-white">Change Password</Link>} />
      <div className="glass-card p-6">
        {user.role === "admin" ? <p className="text-sm text-slate-600">Admin account is seeded through the database. Use change password if needed.</p> : <form className="grid gap-5 md:grid-cols-2" onSubmit={handleSubmit}><InputField label="Full Name" name="full_name" value={form.full_name} onChange={(e) => setForm((prev) => ({ ...prev, full_name: e.target.value }))} required /><InputField label="Phone" name="phone" value={form.phone} onChange={(e) => setForm((prev) => ({ ...prev, phone: e.target.value }))} required /><SelectField label="Gender" name="gender" value={form.gender} onChange={(e) => setForm((prev) => ({ ...prev, gender: e.target.value }))} options={[{ label: "Male", value: "male" }, { label: "Female", value: "female" }, { label: "Other", value: "other" }]} /><InputField label="Date of Birth" name="dob" type="date" value={form.dob} onChange={(e) => setForm((prev) => ({ ...prev, dob: e.target.value }))} required /><label className="block md:col-span-2"><span className="mb-2 block text-sm font-medium text-slate-600">Address</span><textarea name="address" value={form.address} onChange={(e) => setForm((prev) => ({ ...prev, address: e.target.value }))} rows="4" className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-primary-400 focus:ring-4 focus:ring-primary-100" /></label><InputField label="Profile Photo" name="profile_image" type="file" accept="image/*" /><div className="md:col-span-2"><button type="submit" disabled={loading} className="rounded-2xl bg-primary-600 px-5 py-3 text-sm font-semibold text-white">{loading ? "Saving..." : "Save Profile"}</button></div></form>}
      </div>
    </div>
  );
};

export default ProfilePage;
