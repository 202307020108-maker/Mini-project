import clsx from "clsx";
import { getStatusClasses } from "../../utils/format";

const StatusBadge = ({ value }) => (
  <span className={clsx("rounded-full px-3 py-1 text-xs font-semibold capitalize", getStatusClasses(value))}>
    {String(value || "").replace("_", " ")}
  </span>
);

export default StatusBadge;
