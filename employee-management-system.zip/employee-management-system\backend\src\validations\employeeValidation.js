import { body } from "express-validator";

export const employeeValidation = [
  body("employee_code").trim().notEmpty().withMessage("Employee code is required."),
  body("full_name").trim().notEmpty().withMessage("Full name is required."),
  body("email").isEmail().withMessage("Valid email is required."),
  body("phone").trim().notEmpty().withMessage("Phone is required."),
  body("gender").isIn(["male", "female", "other"]).withMessage("Gender is invalid."),
  body("dob").isISO8601().withMessage("Date of birth is required."),
  body("address").trim().notEmpty().withMessage("Address is required."),
  body("department_id").isInt({ min: 1 }).withMessage("Department is required."),
  body("designation").trim().notEmpty().withMessage("Designation is required."),
  body("salary").isFloat({ min: 0 }).withMessage("Salary must be valid."),
  body("joining_date").isISO8601().withMessage("Joining date is required."),
  body("status").isIn(["active", "inactive", "on_leave"]).withMessage("Status is invalid."),
  body("role").isIn(["employee", "admin"]).withMessage("Role is invalid."),
  body("password").optional({ values: "falsy" }).isLength({ min: 4 }).withMessage("Password must be at least 4 characters long.")
];

export const profileValidation = [
  body("full_name").trim().notEmpty().withMessage("Full name is required."),
  body("phone").trim().notEmpty().withMessage("Phone is required."),
  body("gender").isIn(["male", "female", "other"]).withMessage("Gender is invalid."),
  body("dob").isISO8601().withMessage("Date of birth is required."),
  body("address").trim().notEmpty().withMessage("Address is required.")
];
