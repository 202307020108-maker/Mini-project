import express from "express";
import { createDepartment, deleteDepartment, getDepartments, updateDepartment } from "../controllers/departmentController.js";
import { authorize, protect } from "../middleware/auth.js";
import validate from "../middleware/validate.js";
import { departmentValidation } from "../validations/departmentValidation.js";

const router = express.Router();

router.use(protect);
router.get("/", getDepartments);
router.post("/", authorize("admin"), departmentValidation, validate, createDepartment);
router.put("/:id", authorize("admin"), departmentValidation, validate, updateDepartment);
router.delete("/:id", authorize("admin"), deleteDepartment);

export default router;
