import bcrypt from "bcrypt";
import { query } from "../config/db.js";
import { ROLES } from "../constants/index.js";
import AppError from "../utils/AppError.js";
import { successResponse } from "../utils/apiResponse.js";
import catchAsync from "../utils/catchAsync.js";
import { buildFileUrl } from "../utils/file.js";
import { signToken } from "../utils/jwt.js";

const buildAuthPayload = (req, user, role) => ({
  token: signToken({ id: user.id, role }),
  user: { ...user, role, profile_image_url: buildFileUrl(req, user.profile_image || null) }
});

export const login = catchAsync(async (req, res, next) => {
  const { email, password } = req.body;
  const admins = await query(
    "SELECT id, name, email, password, role FROM admins WHERE email = :email LIMIT 1",
    { email }
  );

  if (admins.length) {
    const admin = admins[0];
    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) return next(new AppError("Invalid email or password.", 401));
    return successResponse(
      res,
      "Login successful.",
      buildAuthPayload(req, { id: admin.id, name: admin.name, email: admin.email }, ROLES.ADMIN)
    );
  }

  const employees = await query(
    `SELECT id, employee_code, full_name, email, phone, gender, dob, address, department_id,
            designation, salary, joining_date, status, role, profile_image, password
     FROM employees
     WHERE email = :email LIMIT 1`,
    { email }
  );
  if (!employees.length) return next(new AppError("Invalid email or password.", 401));
  const employee = employees[0];
  const isMatch = await bcrypt.compare(password, employee.password);
  if (!isMatch) return next(new AppError("Invalid email or password.", 401));
  delete employee.password;
  successResponse(res, "Login successful.", buildAuthPayload(req, employee, ROLES.EMPLOYEE));
});

export const getCurrentUser = catchAsync(async (req, res) => {
  if (req.user.role === ROLES.ADMIN) {
    return successResponse(res, "Current user fetched successfully.", { ...req.user, profile_image_url: null });
  }

  const rows = await query(
    `SELECT e.*, d.name AS department_name
     FROM employees e
     LEFT JOIN departments d ON d.id = e.department_id
     WHERE e.id = :id LIMIT 1`,
    { id: req.user.id }
  );
  const employee = rows[0];
  successResponse(res, "Current user fetched successfully.", {
    ...employee,
    profile_image_url: buildFileUrl(req, employee.profile_image)
  });
});

export const changePassword = catchAsync(async (req, res, next) => {
  const { currentPassword, newPassword } = req.body;
  const table = req.user.role === ROLES.ADMIN ? "admins" : "employees";
  const rows = await query(`SELECT id, password FROM ${table} WHERE id = :id LIMIT 1`, { id: req.user.id });
  const isMatch = await bcrypt.compare(currentPassword, rows[0].password);
  if (!isMatch) return next(new AppError("Current password is incorrect.", 400));
  const hashedPassword = await bcrypt.hash(newPassword, 10);
  await query(`UPDATE ${table} SET password = :password WHERE id = :id`, {
    id: req.user.id,
    password: hashedPassword
  });
  successResponse(res, "Password updated successfully.");
});
