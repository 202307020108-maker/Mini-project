/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        primary: {
          50: "#eef7ff",
          100: "#d9ecff",
          200: "#bbddff",
          300: "#8cc6ff",
          400: "#57a8ff",
          500: "#2d8cff",
          600: "#166ee6",
          700: "#1359ba",
          800: "#154c96",
          900: "#18417a"
        }
      },
      boxShadow: {
        soft: "0 18px 45px rgba(15, 23, 42, 0.08)"
      },
      backgroundImage: {
        hero: "radial-gradient(circle at top left, rgba(45,140,255,0.16), transparent 38%), radial-gradient(circle at bottom right, rgba(15,23,42,0.08), transparent 30%)"
      }
    }
  },
  plugins: []
};
