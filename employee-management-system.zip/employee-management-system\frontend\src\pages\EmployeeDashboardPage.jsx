import { CalendarDays, CreditCard, FileClock } from "lucide-react";
import { useEffect, useState } from "react";
import api from "../api/axios";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import StatCard from "../components/common/StatCard";

const EmployeeDashboardPage = () => {
  const [dashboard, setDashboard] = useState(null);
  useEffect(() => { api.get("/dashboard").then(({ data }) => setDashboard(data.data)); }, []);
  if (!dashboard) return <Loader label="Loading your dashboard..." />;
  return (
    <div>
      <PageHeader title="Employee Dashboard" subtitle="View your leave, attendance, and salary snapshots in one place." />
      <div className="grid gap-5 md:grid-cols-3">
        <StatCard title="Pending Leaves" value={dashboard.cards.pendingLeaves} icon={FileClock} />
        <StatCard title="Recent Attendance" value={dashboard.cards.recentAttendance} icon={CalendarDays} />
        <StatCard title="Payroll Records" value={dashboard.cards.payrollRecords} icon={CreditCard} />
      </div>
    </div>
  );
};

export default EmployeeDashboardPage;
