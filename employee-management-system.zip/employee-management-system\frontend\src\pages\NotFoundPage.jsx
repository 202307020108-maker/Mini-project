import { Link } from "react-router-dom";

const NotFoundPage = () => (
  <div className="flex min-h-screen items-center justify-center px-4">
    <div className="glass-card max-w-lg p-8 text-center">
      <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-600">404</p>
      <h1 className="mt-3 text-3xl font-bold text-slate-900">Page Not Found</h1>
      <p className="mt-3 text-sm text-slate-500">The page you are looking for does not exist or has moved.</p>
      <Link to="/login" className="mt-6 inline-flex rounded-2xl bg-primary-600 px-5 py-3 text-sm font-semibold text-white">Go to Login</Link>
    </div>
  </div>
);

export default NotFoundPage;
