import { validationResult } from "express-validator";
import AppError from "../utils/AppError.js";

const validate = (req, _res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return next(
      new AppError("Validation failed.", 422, {
        errors: errors.array().map((item) => ({
          field: item.path,
          message: item.msg
        }))
      })
    );
  }

  next();
};

export default validate;
