import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../api/axios";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import EmployeeForm from "../components/forms/EmployeeForm";

const EditEmployeePage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [form, setForm] = useState(null);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    Promise.all([api.get(`/employees/${id}`), api.get("/departments")]).then(([employeeRes, departmentRes]) => {
      const employee = employeeRes.data.data;
      setForm({ ...employee, dob: employee.dob?.slice(0, 10) || "", joining_date: employee.joining_date?.slice(0, 10) || "", password: "" });
      setDepartments(departmentRes.data.data);
    });
  }, [id]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    const payload = new FormData();
    Object.entries(form).forEach(([key, value]) => {
      if (!["profile_image_url", "created_at", "updated_at", "department_name"].includes(key)) payload.append(key, value ?? "");
    });
    const file = event.target.profile_image.files[0];
    if (file) payload.append("profile_image", file);
    try {
      await api.put(`/employees/${id}`, payload);
      toast.success("Employee updated successfully.");
      navigate("/admin/employees");
    } finally {
      setLoading(false);
    }
  };

  if (!form) return <Loader label="Loading employee details..." />;
  return <div><PageHeader title="Edit Employee" subtitle="Update personal, department, salary, and status information." /><EmployeeForm form={form} departments={departments} loading={loading} submitLabel="Save Changes" onChange={(e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))} onSubmit={handleSubmit} /></div>;
};

export default EditEmployeePage;
