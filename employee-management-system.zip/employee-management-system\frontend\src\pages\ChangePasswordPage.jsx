import { useState } from "react";
import { toast } from "react-toastify";
import api from "../api/axios";
import PageHeader from "../components/common/PageHeader";
import InputField from "../components/forms/InputField";

const ChangePasswordPage = () => {
  const [form, setForm] = useState({ currentPassword: "", newPassword: "" });
  const [loading, setLoading] = useState(false);
  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      await api.patch("/auth/change-password", form);
      setForm({ currentPassword: "", newPassword: "" });
      toast.success("Password changed successfully.");
    } finally {
      setLoading(false);
    }
  };
  return (
    <div>
      <PageHeader title="Change Password" subtitle="Keep your account secure with a fresh password." />
      <form className="glass-card mx-auto max-w-xl space-y-5 p-6" onSubmit={handleSubmit}>
        <InputField label="Current Password" name="currentPassword" type="password" value={form.currentPassword} onChange={(e) => setForm((prev) => ({ ...prev, currentPassword: e.target.value }))} required />
        <InputField label="New Password" name="newPassword" type="password" value={form.newPassword} onChange={(e) => setForm((prev) => ({ ...prev, newPassword: e.target.value }))} required />
        <button type="submit" disabled={loading} className="rounded-2xl bg-primary-600 px-5 py-3 text-sm font-semibold text-white">{loading ? "Updating..." : "Update Password"}</button>
      </form>
    </div>
  );
};

export default ChangePasswordPage;
