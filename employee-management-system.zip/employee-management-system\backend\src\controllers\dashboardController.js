import { query } from "../config/db.js";
import { ROLES } from "../constants/index.js";
import { successResponse } from "../utils/apiResponse.js";
import catchAsync from "../utils/catchAsync.js";

export const getDashboard = catchAsync(async (req, res) => {
  if (req.user.role === ROLES.ADMIN) {
    const [
      employeeCountRows,
      departmentCountRows,
      pendingLeavesRows,
      monthlyPayrollRows,
      departmentDistribution,
      attendanceTrend,
      leaveSummary
    ] = await Promise.all([
      query("SELECT COUNT(*) AS total FROM employees"),
      query("SELECT COUNT(*) AS total FROM departments"),
      query("SELECT COUNT(*) AS total FROM leaves WHERE status = 'pending'"),
      query(`SELECT COALESCE(SUM(net_salary), 0) AS total FROM payroll WHERE month = MONTH(CURDATE()) AND year = YEAR(CURDATE())`),
      query(`SELECT d.name AS department, COUNT(e.id) AS total FROM departments d LEFT JOIN employees e ON e.department_id = d.id GROUP BY d.id ORDER BY total DESC`),
      query(`SELECT DATE_FORMAT(date, '%Y-%m-%d') AS date, SUM(status = 'present') AS present, SUM(status = 'late') AS late, SUM(status = 'absent') AS absent FROM attendance WHERE date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY date ORDER BY date ASC`),
      query("SELECT status, COUNT(*) AS total FROM leaves GROUP BY status")
    ]);

    return successResponse(res, "Admin dashboard loaded.", {
      cards: {
        totalEmployees: employeeCountRows[0].total,
        totalDepartments: departmentCountRows[0].total,
        pendingLeaves: pendingLeavesRows[0].total,
        monthlyPayroll: Number(monthlyPayrollRows[0].total)
      },
      charts: { departmentDistribution, attendanceTrend, leaveSummary }
    });
  }

  const [leaveRows, attendanceRows, payrollRows] = await Promise.all([
    query(`SELECT COUNT(*) AS total FROM leaves WHERE employee_id = :employeeId AND status = 'pending'`, { employeeId: req.user.id }),
    query(`SELECT DATE_FORMAT(date, '%Y-%m-%d') AS date, status FROM attendance WHERE employee_id = :employeeId ORDER BY date DESC LIMIT 7`, { employeeId: req.user.id }),
    query(`SELECT month, year, net_salary, payment_status FROM payroll WHERE employee_id = :employeeId ORDER BY year DESC, month DESC LIMIT 6`, { employeeId: req.user.id })
  ]);

  successResponse(res, "Employee dashboard loaded.", {
    cards: {
      pendingLeaves: leaveRows[0].total,
      recentAttendance: attendanceRows.length,
      payrollRecords: payrollRows.length
    },
    charts: {
      recentAttendance: attendanceRows.reverse(),
      payrollTrend: payrollRows.reverse()
    }
  });
});
