import bcrypt from "bcrypt";
import ExcelJS from "exceljs";
import { query } from "../config/db.js";
import { ROLES } from "../constants/index.js";
import AppError from "../utils/AppError.js";
import { paginatedResponse, successResponse } from "../utils/apiResponse.js";
import catchAsync from "../utils/catchAsync.js";
import { buildFileUrl } from "../utils/file.js";

const employeeSelect = `SELECT e.id, e.employee_code, e.full_name, e.email, e.phone, e.gender, e.dob,
  e.address, e.department_id, d.name AS department_name, e.designation, e.salary,
  e.joining_date, e.status, e.role, e.profile_image, e.created_at, e.updated_at
  FROM employees e
  LEFT JOIN departments d ON d.id = e.department_id`;

const normalizeEmployee = (req, row) => ({
  ...row,
  profile_image_url: buildFileUrl(req, row.profile_image)
});

export const getEmployees = catchAsync(async (req, res) => {
  const page = Number(req.query.page) || 1;
  const limit = Number(req.query.limit) || 10;
  const offset = (page - 1) * limit;
  const search = req.query.search?.trim() || "";
  const departmentId = req.query.departmentId || "";
  const status = req.query.status || "";
  const sortBy = req.query.sortBy || "created_at";
  const sortOrder = req.query.sortOrder === "asc" ? "ASC" : "DESC";
  const allowedSorts = ["created_at", "full_name", "salary", "joining_date"];
  const safeSortBy = allowedSorts.includes(sortBy) ? sortBy : "created_at";
  let where = " WHERE 1=1 ";
  const params = { limit, offset };

  if (search) {
    where += ` AND (e.full_name LIKE :search OR e.email LIKE :search OR e.employee_code LIKE :search OR e.designation LIKE :search)`;
    params.search = `%${search}%`;
  }
  if (departmentId) {
    where += " AND e.department_id = :departmentId";
    params.departmentId = Number(departmentId);
  }
  if (status) {
    where += " AND e.status = :status";
    params.status = status;
  }

  const rows = await query(
    `${employeeSelect} ${where}
     ORDER BY e.${safeSortBy} ${sortOrder}
     LIMIT :limit OFFSET :offset`,
    params
  );
  const countRows = await query(
    `SELECT COUNT(*) AS total FROM employees e LEFT JOIN departments d ON d.id = e.department_id ${where}`,
    params
  );

  paginatedResponse(res, "Employees fetched successfully.", rows.map((row) => normalizeEmployee(req, row)), {
    page,
    limit,
    total: countRows[0].total,
    totalPages: Math.ceil(countRows[0].total / limit)
  });
});

export const getEmployeeById = catchAsync(async (req, res, next) => {
  const rows = await query(`${employeeSelect} WHERE e.id = :id LIMIT 1`, { id: req.params.id });
  if (!rows.length) return next(new AppError("Employee not found.", 404));
  successResponse(res, "Employee fetched successfully.", normalizeEmployee(req, rows[0]));
});

export const createEmployee = catchAsync(async (req, res, next) => {
  const body = req.body;
  if (!body.password) return next(new AppError("Password is required for new employees.", 400));
  const existing = await query(
    "SELECT id FROM employees WHERE email = :email OR employee_code = :employee_code LIMIT 1",
    { email: body.email, employee_code: body.employee_code }
  );
  if (existing.length) return next(new AppError("Employee email or code already exists.", 400));

  const hashedPassword = await bcrypt.hash(body.password, 10);
  const result = await query(
    `INSERT INTO employees (
      employee_code, full_name, email, phone, gender, dob, address, department_id,
      designation, salary, joining_date, status, role, password, profile_image
    ) VALUES (
      :employee_code, :full_name, :email, :phone, :gender, :dob, :address, :department_id,
      :designation, :salary, :joining_date, :status, :role, :password, :profile_image
    )`,
    { ...body, password: hashedPassword, profile_image: req.file?.filename || null }
  );

  const rows = await query(`${employeeSelect} WHERE e.id = :id LIMIT 1`, { id: result.insertId });
  successResponse(res, "Employee created successfully.", normalizeEmployee(req, rows[0]), 201);
});

export const updateEmployee = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const existingRows = await query("SELECT * FROM employees WHERE id = :id LIMIT 1", { id });
  if (!existingRows.length) return next(new AppError("Employee not found.", 404));

  const existing = existingRows[0];
  const body = req.body;
  const duplicateRows = await query(
    `SELECT id FROM employees
     WHERE (email = :email OR employee_code = :employee_code) AND id != :id
     LIMIT 1`,
    { id, email: body.email, employee_code: body.employee_code }
  );
  if (duplicateRows.length) return next(new AppError("Another employee already uses this email or code.", 400));

  const hashedPassword = body.password ? await bcrypt.hash(body.password, 10) : existing.password;
  await query(
    `UPDATE employees
     SET employee_code = :employee_code, full_name = :full_name, email = :email,
         phone = :phone, gender = :gender, dob = :dob, address = :address,
         department_id = :department_id, designation = :designation, salary = :salary,
         joining_date = :joining_date, status = :status, role = :role,
         password = :password, profile_image = :profile_image
     WHERE id = :id`,
    { id, ...body, password: hashedPassword, profile_image: req.file?.filename || existing.profile_image }
  );

  const rows = await query(`${employeeSelect} WHERE e.id = :id LIMIT 1`, { id });
  successResponse(res, "Employee updated successfully.", normalizeEmployee(req, rows[0]));
});

export const deleteEmployee = catchAsync(async (req, res) => {
  await query("DELETE FROM employees WHERE id = :id", { id: req.params.id });
  successResponse(res, "Employee deleted successfully.");
});

export const exportEmployees = catchAsync(async (_req, res) => {
  const rows = await query(
    `SELECT e.employee_code, e.full_name, e.email, e.phone, d.name AS department,
            e.designation, e.salary, e.status, e.joining_date
     FROM employees e
     LEFT JOIN departments d ON d.id = e.department_id
     ORDER BY e.full_name ASC`
  );

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("Employees");
  worksheet.columns = [
    { header: "Employee Code", key: "employee_code", width: 18 },
    { header: "Full Name", key: "full_name", width: 24 },
    { header: "Email", key: "email", width: 28 },
    { header: "Phone", key: "phone", width: 18 },
    { header: "Department", key: "department", width: 18 },
    { header: "Designation", key: "designation", width: 18 },
    { header: "Salary", key: "salary", width: 16 },
    { header: "Status", key: "status", width: 14 },
    { header: "Joining Date", key: "joining_date", width: 18 }
  ];
  rows.forEach((row) => worksheet.addRow(row));
  worksheet.getRow(1).font = { bold: true };
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", "attachment; filename=employees.xlsx");
  await workbook.xlsx.write(res);
  res.end();
});

export const updateMyProfile = catchAsync(async (req, res, next) => {
  if (req.user.role !== ROLES.EMPLOYEE) {
    return next(new AppError("Only employees can update this profile endpoint.", 403));
  }
  const { full_name, phone, gender, dob, address } = req.body;
  const rows = await query("SELECT profile_image FROM employees WHERE id = :id LIMIT 1", { id: req.user.id });
  await query(
    `UPDATE employees
     SET full_name = :full_name, phone = :phone, gender = :gender, dob = :dob,
         address = :address, profile_image = :profile_image
     WHERE id = :id`,
    {
      id: req.user.id,
      full_name,
      phone,
      gender,
      dob,
      address,
      profile_image: req.file?.filename || rows[0].profile_image
    }
  );
  const updated = await query(`${employeeSelect} WHERE e.id = :id LIMIT 1`, { id: req.user.id });
  successResponse(res, "Profile updated successfully.", normalizeEmployee(req, updated[0]));
});
