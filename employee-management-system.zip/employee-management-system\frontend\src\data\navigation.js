import { Building2, CalendarRange, CreditCard, LayoutDashboard, Settings, Users } from "lucide-react";

export const adminNav = [
  { label: "Dashboard", path: "/admin/dashboard", icon: LayoutDashboard },
  { label: "Employees", path: "/admin/employees", icon: Users },
  { label: "Departments", path: "/admin/departments", icon: Building2 },
  { label: "Attendance", path: "/admin/attendance", icon: CalendarRange },
  { label: "Leave", path: "/admin/leaves", icon: CalendarRange },
  { label: "Payroll", path: "/admin/payroll", icon: CreditCard },
  { label: "Profile", path: "/profile", icon: Settings }
];

export const employeeNav = [
  { label: "Dashboard", path: "/employee/dashboard", icon: LayoutDashboard },
  { label: "Attendance", path: "/employee/attendance", icon: CalendarRange },
  { label: "Leave History", path: "/employee/leaves", icon: CalendarRange },
  { label: "Payroll", path: "/employee/payroll", icon: CreditCard },
  { label: "Profile", path: "/profile", icon: Settings }
];
