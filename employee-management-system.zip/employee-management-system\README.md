# Employee Management System

## Demo Credentials

- Admin: `admin@ems.com` / `bacon`
- Employee: `neha.sharma@ems.com` / `bacon`

## Install

```bash
cd employee-management-system
npm install
```

## Run

Backend:

```bash
cd backend
copy .env.example .env
npm run dev
```

Frontend:

```bash
cd frontend
copy .env.example .env
npm run dev
```

## Database

Import:

```sql
SOURCE backend/sql/schema.sql;
```
