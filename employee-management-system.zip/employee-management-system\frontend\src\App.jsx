import { Navigate, Route, Routes } from "react-router-dom";
import ProtectedRoute from "./components/common/ProtectedRoute";
import AppLayout from "./components/layout/AppLayout";
import AddEmployeePage from "./pages/AddEmployeePage";
import AdminDashboardPage from "./pages/AdminDashboardPage";
import AttendancePage from "./pages/AttendancePage";
import ChangePasswordPage from "./pages/ChangePasswordPage";
import DepartmentsPage from "./pages/DepartmentsPage";
import EditEmployeePage from "./pages/EditEmployeePage";
import EmployeeDashboardPage from "./pages/EmployeeDashboardPage";
import EmployeeDetailsPage from "./pages/EmployeeDetailsPage";
import EmployeesPage from "./pages/EmployeesPage";
import LeaveManagementPage from "./pages/LeaveManagementPage";
import LoginPage from "./pages/LoginPage";
import NotFoundPage from "./pages/NotFoundPage";
import PayrollPage from "./pages/PayrollPage";
import ProfilePage from "./pages/ProfilePage";
import UnauthorizedPage from "./pages/UnauthorizedPage";

const App = () => (
  <Routes>
    <Route path="/" element={<Navigate to="/login" replace />} />
    <Route path="/login" element={<LoginPage />} />
    <Route path="/unauthorized" element={<UnauthorizedPage />} />
    <Route element={<ProtectedRoute allowedRoles={["admin", "employee"]} />}>
      <Route element={<AppLayout />}>
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/change-password" element={<ChangePasswordPage />} />
      </Route>
    </Route>
    <Route element={<ProtectedRoute allowedRoles={["admin"]} />}>
      <Route element={<AppLayout />}>
        <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
        <Route path="/admin/employees" element={<EmployeesPage />} />
        <Route path="/admin/employees/new" element={<AddEmployeePage />} />
        <Route path="/admin/employees/:id" element={<EmployeeDetailsPage />} />
        <Route path="/admin/employees/:id/edit" element={<EditEmployeePage />} />
        <Route path="/admin/departments" element={<DepartmentsPage />} />
        <Route path="/admin/attendance" element={<AttendancePage mode="admin" />} />
        <Route path="/admin/leaves" element={<LeaveManagementPage mode="admin" />} />
        <Route path="/admin/payroll" element={<PayrollPage mode="admin" />} />
      </Route>
    </Route>
    <Route element={<ProtectedRoute allowedRoles={["employee"]} />}>
      <Route element={<AppLayout />}>
        <Route path="/employee/dashboard" element={<EmployeeDashboardPage />} />
        <Route path="/employee/attendance" element={<AttendancePage mode="employee" />} />
        <Route path="/employee/leaves" element={<LeaveManagementPage mode="employee" />} />
        <Route path="/employee/payroll" element={<PayrollPage mode="employee" />} />
      </Route>
    </Route>
    <Route path="*" element={<NotFoundPage />} />
  </Routes>
);

export default App;
