import { Building2, CalendarCheck2, CreditCard, Users } from "lucide-react";
import { useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import api from "../api/axios";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import StatCard from "../components/common/StatCard";

const AdminDashboardPage = () => {
  const [dashboard, setDashboard] = useState(null);
  useEffect(() => { api.get("/dashboard").then(({ data }) => setDashboard(data.data)); }, []);
  if (!dashboard) return <Loader label="Loading dashboard insights..." />;
  return (
    <div>
      <PageHeader title="Admin Dashboard" subtitle="Track workforce health, approvals, payroll load, and department distribution in one glance." />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Total Employees" value={dashboard.cards.totalEmployees} icon={Users} />
        <StatCard title="Departments" value={dashboard.cards.totalDepartments} icon={Building2} />
        <StatCard title="Pending Leaves" value={dashboard.cards.pendingLeaves} icon={CalendarCheck2} />
        <StatCard title="Monthly Payroll" value={dashboard.cards.monthlyPayroll} icon={CreditCard} currency />
      </div>
      <div className="mt-6 grid gap-6 xl:grid-cols-2">
        <div className="glass-card p-5">
          <h3 className="text-lg font-semibold text-slate-900">Attendance Trend</h3>
          <div className="mt-5 h-80"><ResponsiveContainer width="100%" height="100%"><BarChart data={dashboard.charts.attendanceTrend}><CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" /><XAxis dataKey="date" /><YAxis /><Tooltip /><Bar dataKey="present" fill="#2d8cff" /><Bar dataKey="late" fill="#f97316" /><Bar dataKey="absent" fill="#ef4444" /></BarChart></ResponsiveContainer></div>
        </div>
        <div className="glass-card p-5">
          <h3 className="text-lg font-semibold text-slate-900">Department Mix</h3>
          <div className="mt-5 h-80"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={dashboard.charts.departmentDistribution} dataKey="total" nameKey="department" outerRadius={120} fill="#2d8cff" /><Tooltip /></PieChart></ResponsiveContainer></div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
