import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import api from "../api/axios";
import ConfirmModal from "../components/common/ConfirmModal";
import DataTable from "../components/common/DataTable";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import StatusBadge from "../components/common/StatusBadge";
import InputField from "../components/forms/InputField";
import SelectField from "../components/forms/SelectField";
import { formatDate } from "../utils/format";

const initialForm = { employee_id: "", date: "", status: "present", check_in: "", check_out: "", remarks: "" };

const AttendancePage = ({ mode }) => {
  const isAdmin = mode === "admin";
  const [attendance, setAttendance] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(initialForm);
  const [editing, setEditing] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const fetchData = async () => {
    setLoading(true);
    try {
      const requests = [api.get("/attendance")];
      if (isAdmin) requests.push(api.get("/employees", { params: { limit: 100, page: 1 } }));
      const [attendanceRes, employeeRes] = await Promise.all(requests);
      setAttendance(attendanceRes.data.data);
      if (employeeRes) setEmployees(employeeRes.data.data);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { fetchData(); }, [mode]);
  const submitAttendance = async (event) => {
    event.preventDefault();
    if (editing) { await api.put(`/attendance/${editing.id}`, form); toast.success("Attendance updated."); } else { await api.post("/attendance", form); toast.success("Attendance added."); }
    setForm(initialForm); setEditing(null); fetchData();
  };
  const deleteAttendance = async () => { await api.delete(`/attendance/${deleteTarget.id}`); toast.success("Attendance removed."); setDeleteTarget(null); fetchData(); };
  if (loading) return <Loader label="Loading attendance..." />;
  return (
    <div>
      <PageHeader title={isAdmin ? "Attendance Management" : "My Attendance"} subtitle={isAdmin ? "Track daily presence, remote days, late arrivals, and absence notes." : "Review your attendance history and work timings."} />
      {isAdmin ? <form className="glass-card mb-6 grid gap-4 p-5 md:grid-cols-3" onSubmit={submitAttendance}><SelectField label="Employee" name="employee_id" value={form.employee_id} onChange={(e) => setForm((prev) => ({ ...prev, employee_id: e.target.value }))} options={[{ label: "Select employee", value: "" }, ...employees.map((item) => ({ label: `${item.full_name} (${item.employee_code})`, value: item.id }))]} /><InputField label="Date" name="date" type="date" value={form.date} onChange={(e) => setForm((prev) => ({ ...prev, date: e.target.value }))} required /><SelectField label="Status" name="status" value={form.status} onChange={(e) => setForm((prev) => ({ ...prev, status: e.target.value }))} options={[{ label: "Present", value: "present" }, { label: "Absent", value: "absent" }, { label: "Late", value: "late" }, { label: "Half Day", value: "half_day" }, { label: "Remote", value: "remote" }]} /><InputField label="Check In" name="check_in" type="time" value={form.check_in} onChange={(e) => setForm((prev) => ({ ...prev, check_in: e.target.value }))} /><InputField label="Check Out" name="check_out" type="time" value={form.check_out} onChange={(e) => setForm((prev) => ({ ...prev, check_out: e.target.value }))} /><InputField label="Remarks" name="remarks" value={form.remarks} onChange={(e) => setForm((prev) => ({ ...prev, remarks: e.target.value }))} /><div className="md:col-span-3 flex gap-3"><button type="submit" className="rounded-2xl bg-primary-600 px-4 py-3 text-sm font-semibold text-white">{editing ? "Update Attendance" : "Add Attendance"}</button></div></form> : null}
      <DataTable columns={[...(isAdmin ? [{ key: "full_name", label: "Employee" }] : []), { key: "date", label: "Date", render: (row) => formatDate(row.date) }, { key: "status", label: "Status", render: (row) => <StatusBadge value={row.status} /> }, { key: "check_in", label: "Check In" }, { key: "check_out", label: "Check Out" }, { key: "remarks", label: "Remarks" }]} rows={attendance} renderActions={isAdmin ? (row) => <div className="flex justify-end gap-2"><button type="button" onClick={() => { setEditing(row); setForm({ ...row, date: row.date.slice(0, 10) }); }} className="rounded-xl border border-slate-200 px-3 py-2 text-primary-700">Edit</button><button type="button" onClick={() => setDeleteTarget(row)} className="rounded-xl border border-rose-200 px-3 py-2 text-rose-600">Delete</button></div> : null} />
      <ConfirmModal open={Boolean(deleteTarget)} title="Delete attendance record" description="This attendance entry will be permanently removed." onCancel={() => setDeleteTarget(null)} onConfirm={deleteAttendance} />
    </div>
  );
};

export default AttendancePage;
