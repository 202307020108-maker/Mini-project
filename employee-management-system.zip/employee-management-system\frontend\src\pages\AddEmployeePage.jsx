import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../api/axios";
import PageHeader from "../components/common/PageHeader";
import EmployeeForm from "../components/forms/EmployeeForm";

const initialForm = { employee_code: "", full_name: "", email: "", phone: "", gender: "female", dob: "", address: "", department_id: "", designation: "", salary: "", joining_date: "", status: "active", role: "employee", password: "" };

const AddEmployeePage = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState(initialForm);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => { api.get("/departments").then(({ data }) => setDepartments(data.data)); }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    const payload = new FormData();
    Object.entries(form).forEach(([key, value]) => payload.append(key, value));
    const file = event.target.profile_image.files[0];
    if (file) payload.append("profile_image", file);
    try {
      await api.post("/employees", payload);
      toast.success("Employee created successfully.");
      navigate("/admin/employees");
    } finally {
      setLoading(false);
    }
  };

  return <div><PageHeader title="Add Employee" subtitle="Create a new employee profile with login access, department mapping, and salary details." /><EmployeeForm form={form} departments={departments} loading={loading} submitLabel="Create Employee" onChange={(e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))} onSubmit={handleSubmit} /></div>;
};

export default AddEmployeePage;
