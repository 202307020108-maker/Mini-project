import clsx from "clsx";
import { LogOut, X } from "lucide-react";
import { NavLink } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { adminNav, employeeNav } from "../../data/navigation";

const Sidebar = ({ mobileOpen, setMobileOpen }) => {
  const { user, logout } = useAuth();
  const navItems = user?.role === "admin" ? adminNav : employeeNav;
  return (
    <>
      {mobileOpen ? <div className="fixed inset-0 z-30 bg-slate-950/35 lg:hidden" onClick={() => setMobileOpen(false)} /> : null}
      <aside className={clsx("fixed left-0 top-0 z-40 h-full w-72 border-r border-white/60 bg-[#0e1c39] p-5 text-white shadow-2xl transition-transform lg:translate-x-0", mobileOpen ? "translate-x-0" : "-translate-x-full")}>
        <div className="mb-8 flex items-center justify-between">
          <div><p className="text-xs uppercase tracking-[0.28em] text-sky-200">College Demo</p><h2 className="mt-2 text-2xl font-bold">EMS Pro</h2></div>
          <button type="button" className="rounded-xl bg-white/10 p-2 lg:hidden" onClick={() => setMobileOpen(false)}><X size={18} /></button>
        </div>
        <nav className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink key={item.path} to={item.path} onClick={() => setMobileOpen(false)} className={({ isActive }) => clsx("flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition", isActive ? "bg-white text-primary-700" : "text-slate-200 hover:bg-white/10")}>
                <Icon size={18} />
                {item.label}
              </NavLink>
            );
          })}
        </nav>
        <button type="button" onClick={logout} className="absolute bottom-6 left-5 right-5 flex items-center justify-center gap-2 rounded-2xl bg-white/10 px-4 py-3 text-sm font-semibold transition hover:bg-white/20">
          <LogOut size={16} />
          Logout
        </button>
      </aside>
    </>
  );
};

export default Sidebar;
