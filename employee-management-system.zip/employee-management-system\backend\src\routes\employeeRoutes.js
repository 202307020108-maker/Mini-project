import express from "express";
import { createEmployee, deleteEmployee, exportEmployees, getEmployeeById, getEmployees, updateEmployee, updateMyProfile } from "../controllers/employeeController.js";
import { authorize, protect } from "../middleware/auth.js";
import { upload } from "../middleware/upload.js";
import validate from "../middleware/validate.js";
import { employeeValidation, profileValidation } from "../validations/employeeValidation.js";

const router = express.Router();

router.use(protect);
router.get("/", authorize("admin"), getEmployees);
router.get("/export/excel", authorize("admin"), exportEmployees);
router.patch("/me/profile", authorize("employee"), upload.single("profile_image"), profileValidation, validate, updateMyProfile);
router.get("/:id", authorize("admin"), getEmployeeById);
router.post("/", authorize("admin"), upload.single("profile_image"), employeeValidation, validate, createEmployee);
router.put("/:id", authorize("admin"), upload.single("profile_image"), employeeValidation, validate, updateEmployee);
router.delete("/:id", authorize("admin"), deleteEmployee);

export default router;
