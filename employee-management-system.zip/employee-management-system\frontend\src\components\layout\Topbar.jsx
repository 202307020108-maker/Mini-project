import { Menu } from "lucide-react";

const Topbar = ({ title, setMobileOpen }) => (
  <div className="glass-card mb-6 flex items-center justify-between gap-4 px-5 py-4">
    <div className="flex items-center gap-3">
      <button type="button" className="rounded-xl bg-primary-50 p-2 text-primary-700 lg:hidden" onClick={() => setMobileOpen(true)}>
        <Menu size={18} />
      </button>
      <div>
        <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
        <p className="text-sm text-slate-500">Manage your workforce with confidence.</p>
      </div>
    </div>
  </div>
);

export default Topbar;
