import { query } from "../config/db.js";
import AppError from "../utils/AppError.js";
import { successResponse } from "../utils/apiResponse.js";
import catchAsync from "../utils/catchAsync.js";

export const getDepartments = catchAsync(async (_req, res) => {
  const rows = await query(
    `SELECT d.*, COUNT(e.id) AS employee_count
     FROM departments d
     LEFT JOIN employees e ON e.department_id = d.id
     GROUP BY d.id
     ORDER BY d.name ASC`
  );
  successResponse(res, "Departments fetched successfully.", rows);
});

export const createDepartment = catchAsync(async (req, res) => {
  const { name, description } = req.body;
  const result = await query(
    "INSERT INTO departments (name, description) VALUES (:name, :description)",
    { name, description: description || null }
  );
  const rows = await query("SELECT * FROM departments WHERE id = :id", { id: result.insertId });
  successResponse(res, "Department created successfully.", rows[0], 201);
});

export const updateDepartment = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { name, description } = req.body;
  const existing = await query("SELECT id FROM departments WHERE id = :id", { id });
  if (!existing.length) return next(new AppError("Department not found.", 404));
  await query("UPDATE departments SET name = :name, description = :description WHERE id = :id", {
    id,
    name,
    description: description || null
  });
  const rows = await query("SELECT * FROM departments WHERE id = :id", { id });
  successResponse(res, "Department updated successfully.", rows[0]);
});

export const deleteDepartment = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const employeeCount = await query("SELECT COUNT(*) AS total FROM employees WHERE department_id = :id", { id });
  if (employeeCount[0].total > 0) {
    return next(new AppError("Cannot delete a department assigned to employees.", 400));
  }
  await query("DELETE FROM departments WHERE id = :id", { id });
  successResponse(res, "Department deleted successfully.");
});
