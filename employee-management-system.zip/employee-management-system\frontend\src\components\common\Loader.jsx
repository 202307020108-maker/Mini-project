const Loader = ({ label = "Loading..." }) => (
  <div className="flex min-h-[240px] items-center justify-center">
    <div className="glass-card flex items-center gap-3 px-6 py-4 text-slate-600">
      <div className="h-3 w-3 animate-pulse rounded-full bg-primary-500" />
      <span>{label}</span>
    </div>
  </div>
);

export default Loader;
