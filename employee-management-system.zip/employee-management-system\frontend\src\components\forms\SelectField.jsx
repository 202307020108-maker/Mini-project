const SelectField = ({ label, options, ...props }) => (
  <label className="block">
    <span className="mb-2 block text-sm font-medium text-slate-600">{label}</span>
    <select {...props} className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-primary-400 focus:ring-4 focus:ring-primary-100">
      {options.map((option) => (
        <option key={option.value} value={option.value}>{option.label}</option>
      ))}
    </select>
  </label>
);

export default SelectField;
