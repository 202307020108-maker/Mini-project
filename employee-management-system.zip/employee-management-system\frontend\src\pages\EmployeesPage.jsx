import { Download, Eye, Pencil, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../api/axios";
import ConfirmModal from "../components/common/ConfirmModal";
import DataTable from "../components/common/DataTable";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import StatusBadge from "../components/common/StatusBadge";
import InputField from "../components/forms/InputField";
import SelectField from "../components/forms/SelectField";
import { formatCurrency, formatDate } from "../utils/format";

const EmployeesPage = () => {
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [pagination, setPagination] = useState({});
  const [filters, setFilters] = useState({ search: "", departmentId: "", status: "", page: 1, limit: 8, sortBy: "created_at", sortOrder: "desc" });
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const fetchEmployees = async () => {
    setLoading(true);
    try {
      const [employeeRes, departmentRes] = await Promise.all([api.get("/employees", { params: filters }), api.get("/departments")]);
      setEmployees(employeeRes.data.data);
      setPagination(employeeRes.data.pagination);
      setDepartments(departmentRes.data.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchEmployees(); }, [filters.page, filters.departmentId, filters.status, filters.sortBy, filters.sortOrder, filters.search]);

  const handleDelete = async () => {
    await api.delete(`/employees/${deleteTarget.id}`);
    toast.success("Employee deleted successfully.");
    setDeleteTarget(null);
    fetchEmployees();
  };

  const exportExcel = async () => {
    const response = await api.get("/employees/export/excel", { responseType: "blob" });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "employees.xlsx");
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const columns = [
    { key: "employee_code", label: "Code" },
    { key: "full_name", label: "Employee" },
    { key: "department_name", label: "Department" },
    { key: "designation", label: "Designation" },
    { key: "salary", label: "Salary", render: (row) => formatCurrency(row.salary) },
    { key: "joining_date", label: "Joining Date", render: (row) => formatDate(row.joining_date) },
    { key: "status", label: "Status", render: (row) => <StatusBadge value={row.status} /> }
  ];

  return (
    <div>
      <PageHeader title="Employees" subtitle="Search, filter, sort, review, and manage every employee record." action={<div className="flex gap-3"><button type="button" onClick={exportExcel} className="rounded-2xl border border-primary-200 bg-white px-4 py-3 text-sm font-semibold text-primary-700"><span className="inline-flex items-center gap-2"><Download size={16} /> Export Excel</span></button><Link to="/admin/employees/new" className="rounded-2xl bg-primary-600 px-4 py-3 text-sm font-semibold text-white"><span className="inline-flex items-center gap-2"><Plus size={16} /> Add Employee</span></Link></div>} />
      <div className="glass-card mb-6 grid gap-4 p-5 md:grid-cols-4">
        <InputField label="Search" value={filters.search} onChange={(e) => setFilters((prev) => ({ ...prev, search: e.target.value, page: 1 }))} />
        <SelectField label="Department" value={filters.departmentId} onChange={(e) => setFilters((prev) => ({ ...prev, departmentId: e.target.value, page: 1 }))} options={[{ label: "All departments", value: "" }, ...departments.map((item) => ({ label: item.name, value: item.id }))]} />
        <SelectField label="Status" value={filters.status} onChange={(e) => setFilters((prev) => ({ ...prev, status: e.target.value, page: 1 }))} options={[{ label: "All statuses", value: "" }, { label: "Active", value: "active" }, { label: "Inactive", value: "inactive" }, { label: "On Leave", value: "on_leave" }]} />
        <SelectField label="Sort By" value={`${filters.sortBy}-${filters.sortOrder}`} onChange={(e) => { const [sortBy, sortOrder] = e.target.value.split("-"); setFilters((prev) => ({ ...prev, sortBy, sortOrder })); }} options={[{ label: "Newest", value: "created_at-desc" }, { label: "Name A-Z", value: "full_name-asc" }, { label: "Salary High-Low", value: "salary-desc" }, { label: "Joining Latest", value: "joining_date-desc" }]} />
      </div>
      {loading ? <Loader label="Loading employees..." /> : <><DataTable columns={columns} rows={employees} renderActions={(row) => <div className="flex justify-end gap-2"><Link to={`/admin/employees/${row.id}`} className="rounded-xl border border-slate-200 p-2 text-slate-600"><Eye size={16} /></Link><Link to={`/admin/employees/${row.id}/edit`} className="rounded-xl border border-slate-200 p-2 text-primary-700"><Pencil size={16} /></Link><button type="button" onClick={() => setDeleteTarget(row)} className="rounded-xl border border-rose-200 p-2 text-rose-600"><Trash2 size={16} /></button></div>} /><div className="mt-5 flex items-center justify-between text-sm text-slate-500"><p>Showing page {pagination.page || 1} of {pagination.totalPages || 1}</p><div className="flex gap-3"><button type="button" disabled={(pagination.page || 1) <= 1} onClick={() => setFilters((prev) => ({ ...prev, page: prev.page - 1 }))} className="rounded-xl border border-slate-200 px-4 py-2 disabled:opacity-50">Previous</button><button type="button" disabled={(pagination.page || 1) >= (pagination.totalPages || 1)} onClick={() => setFilters((prev) => ({ ...prev, page: prev.page + 1 }))} className="rounded-xl border border-slate-200 px-4 py-2 disabled:opacity-50">Next</button></div></div></>}
      <ConfirmModal open={Boolean(deleteTarget)} title="Delete employee" description={`This will permanently remove ${deleteTarget?.full_name || "this employee"} from the system.`} onCancel={() => setDeleteTarget(null)} onConfirm={handleDelete} />
    </div>
  );
};

export default EmployeesPage;
