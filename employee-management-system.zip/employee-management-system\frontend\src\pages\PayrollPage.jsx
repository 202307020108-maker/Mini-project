import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import api from "../api/axios";
import ConfirmModal from "../components/common/ConfirmModal";
import DataTable from "../components/common/DataTable";
import Loader from "../components/common/Loader";
import PageHeader from "../components/common/PageHeader";
import StatusBadge from "../components/common/StatusBadge";
import InputField from "../components/forms/InputField";
import SelectField from "../components/forms/SelectField";
import { formatCurrency } from "../utils/format";

const initialForm = { employee_id: "", month: "", year: new Date().getFullYear(), basic_salary: "", bonus: "", deductions: "", net_salary: "", payment_status: "pending" };

const PayrollPage = ({ mode }) => {
  const isAdmin = mode === "admin";
  const [payrolls, setPayrolls] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(initialForm);
  const [editing, setEditing] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const requests = [api.get("/payroll")];
      if (isAdmin) requests.push(api.get("/employees", { params: { limit: 100, page: 1 } }));
      const [payrollRes, employeeRes] = await Promise.all(requests);
      setPayrolls(payrollRes.data.data);
      if (employeeRes) setEmployees(employeeRes.data.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [mode]);
  useEffect(() => {
    const basic = Number(form.basic_salary || 0);
    const bonus = Number(form.bonus || 0);
    const deductions = Number(form.deductions || 0);
    setForm((prev) => ({ ...prev, net_salary: String(basic + bonus - deductions) }));
  }, [form.basic_salary, form.bonus, form.deductions]);

  const submitPayroll = async (event) => {
    event.preventDefault();
    if (editing) { await api.put(`/payroll/${editing.id}`, form); toast.success("Payroll updated."); } else { await api.post("/payroll", form); toast.success("Payroll generated."); }
    setEditing(null); setForm(initialForm); fetchData();
  };
  const deletePayroll = async () => { await api.delete(`/payroll/${deleteTarget.id}`); toast.success("Payroll deleted."); setDeleteTarget(null); fetchData(); };
  if (loading) return <Loader label="Loading payroll records..." />;
  return (
    <div>
      <PageHeader title={isAdmin ? "Payroll Management" : "My Payroll"} subtitle={isAdmin ? "Generate salary records, apply bonuses and deductions, and manage payout state." : "Review your salary slips and payment status."} />
      {isAdmin ? <form className="glass-card mb-6 grid gap-4 p-5 md:grid-cols-3 xl:grid-cols-4" onSubmit={submitPayroll}><SelectField label="Employee" name="employee_id" value={form.employee_id} onChange={(e) => setForm((prev) => ({ ...prev, employee_id: e.target.value }))} options={[{ label: "Select employee", value: "" }, ...employees.map((item) => ({ label: `${item.full_name} (${item.employee_code})`, value: item.id }))]} /><InputField label="Month" name="month" type="number" min="1" max="12" value={form.month} onChange={(e) => setForm((prev) => ({ ...prev, month: e.target.value }))} required /><InputField label="Year" name="year" type="number" value={form.year} onChange={(e) => setForm((prev) => ({ ...prev, year: e.target.value }))} required /><InputField label="Basic Salary" name="basic_salary" type="number" value={form.basic_salary} onChange={(e) => setForm((prev) => ({ ...prev, basic_salary: e.target.value }))} required /><InputField label="Bonus" name="bonus" type="number" value={form.bonus} onChange={(e) => setForm((prev) => ({ ...prev, bonus: e.target.value }))} /><InputField label="Deductions" name="deductions" type="number" value={form.deductions} onChange={(e) => setForm((prev) => ({ ...prev, deductions: e.target.value }))} /><InputField label="Net Salary" name="net_salary" type="number" value={form.net_salary} onChange={(e) => setForm((prev) => ({ ...prev, net_salary: e.target.value }))} required /><SelectField label="Payment Status" name="payment_status" value={form.payment_status} onChange={(e) => setForm((prev) => ({ ...prev, payment_status: e.target.value }))} options={[{ label: "Pending", value: "pending" }, { label: "Processing", value: "processing" }, { label: "Paid", value: "paid" }]} /><div className="xl:col-span-4 flex gap-3"><button type="submit" className="rounded-2xl bg-primary-600 px-4 py-3 text-sm font-semibold text-white">{editing ? "Update Payroll" : "Generate Payroll"}</button></div></form> : null}
      <DataTable columns={[...(isAdmin ? [{ key: "full_name", label: "Employee" }] : []), { key: "month", label: "Month" }, { key: "year", label: "Year" }, { key: "basic_salary", label: "Basic", render: (row) => formatCurrency(row.basic_salary) }, { key: "bonus", label: "Bonus", render: (row) => formatCurrency(row.bonus) }, { key: "deductions", label: "Deductions", render: (row) => formatCurrency(row.deductions) }, { key: "net_salary", label: "Net Salary", render: (row) => formatCurrency(row.net_salary) }, { key: "payment_status", label: "Status", render: (row) => <StatusBadge value={row.payment_status} /> }]} rows={payrolls} renderActions={isAdmin ? (row) => <div className="flex justify-end gap-2"><button type="button" onClick={() => { setEditing(row); setForm({ ...row }); }} className="rounded-xl border border-slate-200 px-3 py-2 text-primary-700">Edit</button><button type="button" onClick={() => setDeleteTarget(row)} className="rounded-xl border border-rose-200 px-3 py-2 text-rose-600">Delete</button></div> : null} />
      <ConfirmModal open={Boolean(deleteTarget)} title="Delete payroll record" description="This payroll entry will be permanently removed." onCancel={() => setDeleteTarget(null)} onConfirm={deletePayroll} />
    </div>
  );
};

export default PayrollPage;
